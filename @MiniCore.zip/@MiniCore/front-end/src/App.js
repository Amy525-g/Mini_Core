import React from "react";
import Gastos from "./Gastos";

function App() {
  return (
    <div className="App">
      <Gastos />
    </div>
  );
}

export default App;
